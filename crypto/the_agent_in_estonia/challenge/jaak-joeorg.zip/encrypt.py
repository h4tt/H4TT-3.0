#!/usr/bin/env python3

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
backend = default_backend()

with open("card_pub.pem", "rb") as f:
    public_key = serialization.load_pem_public_key(f.read(), backend=backend)

with open("flag.txt", "rb") as f:
    plaintext = f.read()

ciphertext = public_key.encrypt(plaintext, padding.PKCS1v15())

with open("flag.txt.enc", "wb") as f:
    f.write(ciphertext)
